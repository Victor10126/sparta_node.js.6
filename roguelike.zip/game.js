import chalk from 'chalk';
import readlineSync from 'readline-sync';

class Player {
  constructor() {
    this.hp = 100;
  }

  attack() {
    // 플레이어의 공격
    return Math.floor(Math.random())
  }
}

class Monster {
  constructor() {
    this.hp = 70;
  }

  attack() {
    // 몬스터의 공격    
    return Math.floor(Math.random())
  }
}

function displayStatus(stage, player, monster) {
  console.log(chalk.magentaBright(`\n=== Current Status ===`));
  console.log(
    chalk.cyanBright(`| Stage: ${stage} `) +
    chalk.blueBright(
      `| 플레이어 : HP - ${player.hp}`,
      `| 공격력 : Att - ${player.Att}`,
    ) +
    chalk.redBright(
      `| 몬스터 : HP - ${monster.hp}|`,
      `| 공격력 : Att - ${monster.Att}`,
    ),
  );
  console.log(chalk.magentaBright(`=====================\n`));
}

const battle = async (stage, player, monster) => {
  let logs = [];

  while(player.hp > 0 && monster.hp > 0) {
    console.clear();

    displayStatus(stage, player, monster);
    console.log("적대적인 존재가 당신을 노린다")
    logs.forEach((log) => console.log(log));

    console.log(
      chalk.green(
        `\n1. 공격한다 2. 아무것도 하지않는다.`,
      ),
    );

    // switch로 선택한 행동 처리    
    const choice = readlineSync.question('당신의 선택은? ');

    // 플레이어의 선택에 따라 다음 행동 처리
    switch (choice) {
      // 공격
      case "1" :
      const attPlayer = player.attack();
      const attMonster = monster.attack();

      monster.hp -= attPlayer;
      logs.push(chalk.green(`적대적인 존재는 ${attPlayer}의 피해를 입었다!`));
      player.hp -= attMonster;
      logs.push(chalk.red(`당신은 적재적인 존재로부터 ${attMonster}의 피해를 입었다!`));

      break;

      // 방어
      case "2" :
      
    }
    
    if(player.hp < 0){
      console.log(chalk.red("당신은 끝내 사망하였다. 게임 종료."),);
      process.exit();
    }else{
      console.log(chalk.yellow("적대적인 존재를 물리쳤다. 당신의 여정은 계속된다."),);
    }
    
  }
  
};

export async function startGame() {
  console.clear();
  // 플레이어 객체 생선
  const player = new Player();
  let stage = 1;

  while (stage <= 10) {
    // 몬스터 객체 생성
    const monster = new Monster(stage);
    await battle(stage, player, monster);

    // 스테이지 클리어 및 게임 종료 조건

    stage++;
  }

  console.log("당신은 무사히 미로를 벗어나 생존하였다.")

}
